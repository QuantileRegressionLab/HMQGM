// [[Rcpp::depends(RcppArmadillo)]]

# include <RcppArmadillo.h>
# include <stdio.h>
# include <cmath>
# include <iostream>

using namespace Rcpp;
using namespace arma;
using namespace std;

// [[Rcpp::export]]
List core(arma::mat& Y, arma::cube& beta, arma::mat& sigma, arma::vec& tauvec, int ns, int P, int K, int L)
{
  arma::mat fden = zeros(ns, L), Yp = zeros(ns, P), betalp = zeros(K, 1);
  arma::cube mu = zeros(ns, L, P);
  arma::vec oones = ones(ns), tmp = zeros(P);
  double tau = 0;
  int p, l, t;
  
  for(p = 0; p < P; ++p) {
    for(l = 0; l < L; ++l) {
      Yp = Y;
      betalp = beta(span(p), span(), span(l));
      Yp.shed_col(p);
      Yp.insert_cols(0, oones);
      mu(span(), span(l), span(p)) = Yp * trans(betalp);
    }
  }
  
  for(t = 0; t < ns; ++t) {
    for(l = 0; l < L; ++l) {
      tau = tauvec(l);
      for(p = 0; p < P; ++p) {
        tmp(p) = (Y(t, p) < mu(t, l, p)) ? (tau * (1 - tau) / sigma(l,p)) * exp((1 - tau) * (Y(t, p) - mu(t, l, p)) / sigma(l,p)) :
        (tau * (1 - tau) / sigma(l,p)) * exp(-(tau) * (Y(t, p) - mu(t, l, p)) / sigma(l,p));
      }
      fden(t, l) = prod(tmp);
    }
  }
  
  List lout;
  lout["mu"] = mu;
  lout["fden"] = fden;
  lout["tmp"] = tmp;
  
  return lout;
}

// [[Rcpp::export]]
List forward(arma::cube& fden, arma::vec& delta, arma::mat& gamma, int ns, int K, int L)
{
  arma::cube a = zeros(ns, L, K);
  arma::vec foo = zeros(K), tmp = zeros(K);
  arma::mat c_scale = zeros(ns, L);
  int t, l;
  
  for(l = 0; l < L; ++l) {
    foo = fden(span(0), span(l), span());
    foo = delta % foo;
    c_scale(0, l) = 1 / accu(foo);
    foo = foo * c_scale(0, l);
    //foo.print();
    a(span(0), span(l), span()) = foo;
    for(t = 1; t < ns; ++t) {
      tmp = fden(span(t), span(l), span());
      foo = trans(trans(foo) * gamma * diagmat(tmp));
      c_scale(t, l) = 1 / accu(foo);
      foo = foo * c_scale(t, l);
      a(span(t), span(l), span()) = foo;
    }
  }
  
  List lout;
  lout["a"] = a;
  lout["c_scale"] = c_scale;
  
  return lout;
}

// [[Rcpp::export]]
arma::cube backward(arma::cube& fden, arma::vec& delta, arma::mat& gamma, int ns, int K, int L)
{
  arma::cube b = ones(ns, L, K);
  arma::vec foo = zeros(K), tmp = zeros(K);
  double maxfoo = 0;
  int t, l;
  
  for(l = 0; l < L; ++l) {
    foo = ones(K);
    for(t = ns - 2; t >= 0; t--) {
      tmp = fden(span(t+1), span(l), span());
      //tmp.print();
      foo = gamma * diagmat(tmp) * foo;
      maxfoo = max(foo);
      foo /= maxfoo;
      //foo.print();
      b(span(t), span(l), span()) = foo;
    }
  }
  
  return b;
}

// [[Rcpp::export]]
arma::cube vnum(arma::cube& a, arma::cube& b, arma::cube& fden, arma::mat& gamma, arma::cube& nu_vec, int ns, int K, int L)
{
  arma::cube v = zeros(ns, K, K);
  int t, h, k;
  
  for(t = 0; t < ns - 1; ++t) {
    for(h = 0; h < K; ++h) {
      for(k = 0; k < K; ++k) {
        v(t,h,k) = gamma(h,k) * accu(a(span(t), span(), span(h)) % fden(span(t+1), span(), span(k)) % b(span(t+1), span(), span(k)) % nu_vec);
      }
    }
  }
  
  return v;
}
